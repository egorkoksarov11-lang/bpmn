"""Reference-driven BPMN layout with unchanged business semantics."""
__version__ = "23.7.0"
